import {
  Component,
  OnInit
} from '@angular/core';
import {
  FormBuilder,
  FormControl
} from '@angular/forms';
import {
  PhonebookService
} from 'src/app/service/phonebook.service';

@Component({
  selector: 'app-view-phone-book',
  templateUrl: './view-phone-book.component.html',
  styleUrls: ['./view-phone-book.component.css']
})
export class ViewPhoneBookComponent implements OnInit {
  phoneBookList: any;
  searchForm: any;
  filteredBookList: any;

  constructor(private _fb: FormBuilder, private phonebookService: PhonebookService) {
    this.phoneBookList = this.phonebookService.getPhoneBookData()
    this.filteredBookList = this.phoneBookList
  }

  ngOnInit(): void {
    this.searchForm = this._fb.group({
      searchNumber: new FormControl(''),
    })

  }

  applySarchFilter(event: KeyboardEvent) {
    let inputValue = this.searchForm.controls['searchNumber'].value;
    if (event.code === 'Backspace' && !inputValue) {
      this.filteredBookList = this.phoneBookList
    } else {
      this.filteredBookList = this.phoneBookList.filter((item: any) => {
        return item.phone.includes(inputValue);
      });
    }
  }

}
